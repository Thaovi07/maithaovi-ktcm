"""
KTCM AI Analytics Studio - Vercel Serverless Function & Local Flask Entrypoint
Lead Data Analyst: Mai Thảo Vi
"""
import os
import io
import json
import base64
import urllib.parse
from flask import Flask, request, jsonify, send_file, Response, make_response, send_from_directory

try:
    from api.session_store import session_manager
    from api import core_engine as ce
except ImportError:
    from session_store import session_manager
    import core_engine as ce

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "public") if os.path.exists(os.path.join(BASE_DIR, "public")) else os.path.join(BASE_DIR, "static")
SAMPLE_DIR = os.path.join(BASE_DIR, "sample_data")

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

def get_current_session():
    # Session ID resolution: Header > Query param > Cookie > Auto-generated UUID
    sess_id = request.headers.get("X-Session-ID") or request.args.get("session_id") or request.cookies.get("ktcm_session_id")
    sess_id, sess = session_manager.get_or_create(sess_id)
    return sess_id, sess

def session_json_response(sess_id, data, status_code=200):
    resp = make_response(jsonify(data), status_code)
    resp.headers["X-Session-ID"] = sess_id
    resp.set_cookie("ktcm_session_id", sess_id, max_age=7200, httponly=False, samesite="Lax")
    return resp

def ensure_session_data(sess):
    if sess.get("cleaned_df") is None and sess.get("raw_df") is None:
        sample_path = os.path.join(SAMPLE_DIR, "du_lieu_kinh_doanh_mau.csv")
        if os.path.exists(sample_path):
            import pandas as pd
            raw_df = pd.read_csv(sample_path)
            sess["raw_df"] = raw_df
            sess["filename"] = "du_lieu_kinh_doanh_mau.csv"
            cleaned_df, log, diff_cells, stats = ce.execute_cleaning_pipeline(raw_df)
            sess["cleaned_df"] = cleaned_df.copy()
            sess["audited_df"] = cleaned_df.copy()
            sess["clean_log"] = log
            sess["clean_diff_cells"] = diff_cells
            sess["clean_stats"] = stats
            sess["business"] = ce.detect_business_context(raw_df, "du_lieu_kinh_doanh_mau.csv")

# ==============================================================================
# API ROUTES (23 ENDPOINTS)
# ==============================================================================

@app.route('/api/status', methods=['GET'])
def api_status():
    sess_id, sess = get_current_session()
    has_file = sess.get("raw_df") is not None or sess.get("cleaned_df") is not None
    row_count = len(sess.get("cleaned_df", sess.get("raw_df", []))) if has_file else 0
    return session_json_response(sess_id, {
        "status": "ONLINE",
        "app": "KTCM AI Analytics Studio",
        "environment": "Vercel Serverless / Flask",
        "version": "2.4.0",
        "session_id": sess_id,
        "lead_analyst": "Mai Thảo Vi",
        "has_file": has_file,
        "filename": sess.get("filename"),
        "row_count": row_count
    })

@app.route('/api/load-sample', methods=['POST'])
def api_load_sample():
    sess_id, sess = get_current_session()
    req = request.get_json(silent=True) or {}
    filename = req.get("filename", "du_lieu_kinh_doanh_mau.csv")
    file_path = os.path.join(SAMPLE_DIR, filename)

    if not os.path.exists(file_path):
        return session_json_response(sess_id, {"error": "Tệp mẫu không tồn tại"}, 404)

    import pandas as pd
    if filename.endswith(".xlsx"):
        df = pd.read_excel(file_path)
    else:
        df = pd.read_csv(file_path)

    sess["raw_df"] = df.copy()
    sess["filename"] = filename
    sess["business"] = ce.detect_business_context(df, filename)

    cleaned_df, log, diff_cells, stats = ce.execute_cleaning_pipeline(df)
    sess["cleaned_df"] = cleaned_df.copy()
    sess["audited_df"] = cleaned_df.copy()
    sess["clean_log"] = log
    sess["clean_diff_cells"] = diff_cells
    sess["clean_stats"] = stats
    sess["is_audited"] = False
    sess["analysis_cache"] = None

    profile = ce.profile_dataframe(df)
    audit = ce.audit_raw_file_health(df, filename)
    auto_ctx = sess.get("business", {})
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "filename": filename,
        "business": auto_ctx,
        "auto_context": auto_ctx,
        "audit": audit,
        "total_rows": len(df),
        "row_count": len(df),
        "total_cols": len(df.columns),
        "col_count": len(df.columns),
        "columns": profile,
        "preview": ce.dataframe_to_records(df.head(10))
    })

@app.route('/api/upload-raw', methods=['POST'])
def api_upload_raw():
    sess_id, sess = get_current_session()
    req = request.get_json(silent=True) or {}
    filename = req.get("filename", "data.csv")
    content = req.get("content", "")
    business = req.get("business", {})
    file_type = req.get("type", "csv")

    if not content or len(content.strip()) == 0:
        return session_json_response(sess_id, {
            "success": False,
            "is_critical": True,
            "error_title": "Tệp dữ liệu rỗng (0 bytes)",
            "error_message": "Tệp bạn vừa tải lên hoàn toàn không có nội dung.",
            "advice": "Vui lòng kiểm tra lại tệp nguồn và chọn tệp có chứa bảng dữ liệu."
        }, 400)

    import pandas as pd
    df = None
    try:
        if file_type == "excel" or filename.lower().endswith((".xlsx", ".xls")):
            raw_base64 = content
            if "base64," in raw_base64:
                raw_base64 = raw_base64.split("base64,")[1]
            excel_bytes = base64.b64decode(raw_base64)
            df = pd.read_excel(io.BytesIO(excel_bytes))
        else:
            try:
                df = pd.read_csv(io.StringIO(content), sep=None, engine='python')
            except Exception:
                df = pd.read_csv(io.StringIO(content))
    except Exception as e:
        return session_json_response(sess_id, {
            "success": False,
            "is_critical": True,
            "error_title": "Không thể giải mã hoặc đọc cấu trúc tệp",
            "error_message": f"Tệp tải lên không đúng định dạng. Lỗi kỹ thuật: {str(e)}",
            "advice": "Vui lòng xuất lại tệp dưới dạng .xlsx hoặc .csv chuẩn UTF-8."
        }, 400)

    if df is not None:
        df.columns = [str(c).strip() for c in df.columns]
        unnamed = [c for c in df.columns if str(c).startswith("Unnamed:") and df[c].isna().all()]
        if unnamed:
            df = df.drop(columns=unnamed)

    audit = ce.audit_raw_file_health(df, filename)
    if not audit["is_valid"]:
        return session_json_response(sess_id, {
            "success": False,
            "is_critical": True,
            "error_title": "Cảnh báo tệp dữ liệu không hợp lệ",
            "error_message": audit["critical_message"],
            "advice": "Tệp cần có ít nhất một dòng tiêu đề và các dòng dữ liệu để phân tích."
        }, 400)

    auto_ctx = audit["auto_context"]
    final_business = business if (business and business.get("industry") and business.get("background")) else auto_ctx

    sess["raw_df"] = df.copy()
    sess["cleaned_df"] = df.copy()
    sess["audited_df"] = df.copy()
    sess["filename"] = filename
    sess["business"] = final_business
    sess["analysis_cache"] = None
    sess["clean_log"] = []
    sess["clean_diff_cells"] = []
    sess["clean_stats"] = {}
    sess["is_audited"] = False

    profile = ce.profile_dataframe(df)
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "filename": filename,
        "total_rows": len(df),
        "row_count": len(df),
        "total_cols": len(df.columns),
        "col_count": len(df.columns),
        "columns": profile,
        "preview": ce.dataframe_to_records(df.head(10)),
        "audit": audit,
        "auto_context": final_business
    })

@app.route('/api/discovery', methods=['POST'])
def api_discovery():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    raw_df = sess.get("raw_df")
    profile = ce.profile_dataframe(raw_df)
    sess["discovery"] = profile
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "columns": profile,
        "total_rows": len(raw_df) if raw_df is not None else 0,
        "total_cols": len(raw_df.columns) if raw_df is not None else 0,
        "preview": ce.dataframe_to_records(raw_df.head(10)) if raw_df is not None else []
    })

@app.route('/api/clean-detect', methods=['POST'])
def api_clean_detect():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    raw_df = sess.get("raw_df")
    audit = ce.audit_raw_file_health(raw_df, sess.get("filename", ""))
    return session_json_response(sess_id, audit)

@app.route('/api/clean-apply', methods=['POST'])
def api_clean_apply():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    raw_df = sess.get("raw_df")
    req = request.get_json(silent=True) or {}
    options = req.get("options", {})

    cleaned_df, log, diff_cells, stats = ce.execute_cleaning_pipeline(raw_df, options)
    sess["cleaned_df"] = cleaned_df.copy()
    sess["audited_df"] = cleaned_df.copy()
    sess["clean_log"] = log
    sess["clean_diff_cells"] = diff_cells
    sess["clean_stats"] = stats
    sess["is_audited"] = False
    sess["analysis_cache"] = None

    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "log": log,
        "diff_count": len(diff_cells),
        "stats": stats,
        "total_cleaned_rows": len(cleaned_df)
    })

@app.route('/api/audit-diff', methods=['GET', 'POST'])
def api_audit_diff():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    raw_df = sess.get("raw_df")
    cleaned_df = sess.get("cleaned_df")
    diff_cells = sess.get("clean_diff_cells", [])
    stats = sess.get("clean_stats", {})
    active_df = sess.get("audited_df", cleaned_df)

    diff_row_indices = stats.get("diff_row_indices", sorted(list(set(d.get("row_idx", 0) for d in diff_cells))))
    records = ce.dataframe_to_records_with_diff(active_df, diff_row_indices)

    raw_len = stats.get("raw_total", len(raw_df) if raw_df is not None else 0)
    cleaned_len = len(active_df) if active_df is not None else 0
    dup_count = stats.get("dup_count", 0)
    empty_count = stats.get("empty_count", 0)
    error_count = stats.get("error_count", dup_count + empty_count + len(diff_cells))
    valid_count = max(0, cleaned_len - len(diff_row_indices))

    return session_json_response(sess_id, {
        "raw_count": raw_len,
        "valid_count": valid_count,
        "error_count": error_count,
        "cleaned_count": cleaned_len,
        "stats": {
            "raw_rows": raw_len,
            "valid_count": valid_count,
            "error_count": error_count,
            "handled_count": error_count,
            "current_rows": cleaned_len,
            "dup_count": dup_count,
            "empty_count": empty_count,
            "diff_cells_count": len(diff_cells)
        },
        "diff_cells": diff_cells,
        "diff_row_indices": diff_row_indices,
        "columns": list(active_df.columns) if active_df is not None else [],
        "records": records,
        "is_audited": sess.get("is_audited", False)
    })

@app.route('/api/audit-update-cell', methods=['POST'])
def api_audit_update_cell():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    row_idx = req.get("row_idx")
    column = req.get("column")
    new_value = req.get("value")

    df = sess.get("audited_df", sess.get("cleaned_df"))
    if df is not None and row_idx is not None and column in df.columns:
        old_val = df.iloc[row_idx][column]
        df.iloc[row_idx, df.columns.get_loc(column)] = new_value
        sess["audited_df"] = df
        sess["audit_changes"].append({
            "row_idx": row_idx,
            "column": column,
            "old_value": ce.safe_json_value(old_val),
            "new_value": ce.safe_json_value(new_value)
        })
        session_manager.save(sess_id, sess)
        return session_json_response(sess_id, {"success": True, "saved_value": new_value})

    return session_json_response(sess_id, {"error": "Dòng hoặc cột không hợp lệ"}, 400)

@app.route('/api/audit-confirm', methods=['POST'])
def api_audit_confirm():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    sess["is_audited"] = True
    if sess.get("audited_df") is not None:
        sess["cleaned_df"] = sess["audited_df"].copy()
    sess["analysis_cache"] = None
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "message": "Đã nghiệm thu và xác nhận số liệu kiểm toán thành công.",
        "row_count": len(sess["cleaned_df"])
    })

@app.route('/api/group-analysis', methods=['POST'])
def api_group_analysis():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    dim = req.get("dimension")
    metric = req.get("metric")
    df = sess.get("cleaned_df", sess.get("raw_df"))

    if df is None or dim not in df.columns or metric not in df.columns:
        return session_json_response(sess_id, {"error": "Cột không hợp lệ"}, 400)

    import pandas as pd
    df = ce.standardize_dataframe_numeric_types(df)
    grouped = df.groupby(dim, dropna=False)[metric].agg(['sum', 'mean', 'count']).reset_index()
    grouped = grouped.sort_values(by='sum', ascending=False)
    tot = grouped['sum'].sum()

    items = []
    for _, r in grouped.iterrows():
        val = float(r['sum'])
        pct = round(val / tot * 100, 1) if tot > 0 else 0
        items.append({
            "label": str(r[dim]),
            "value": val,
            "pct": pct,
            "mean": float(r['mean']),
            "count": int(r['count'])
        })

    return session_json_response(sess_id, {
        "dimension": dim,
        "metric": metric,
        "items": items,
        "total": float(tot)
    })

@app.route('/api/filter-dashboard', methods=['POST'])
def api_filter_dashboard():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    channel = req.get("channel", "ALL")
    region = req.get("region", "ALL")
    filters = req.get("filters", {})

    df = sess.get("cleaned_df", sess.get("raw_df"))
    if df is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu"}, 400)

    slice_data = ce.compute_dashboard_filter_slice(df, channel, region, filters)
    return session_json_response(sess_id, slice_data)

@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    df = sess.get("cleaned_df", sess.get("raw_df"))
    if df is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu làm sạch"}, 400)

    analysis = ce.compute_deep_analysis(df, sess.get("business", {}))
    sess["analysis_cache"] = analysis
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, analysis)

@app.route('/api/ai-chat', methods=['POST'])
def api_ai_chat():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    user_q = req.get("message", "").strip()
    df = sess.get("cleaned_df", sess.get("raw_df"))

    if not user_q:
        return session_json_response(sess_id, {"answer": "Bạn vui lòng đặt câu hỏi về dữ liệu kinh doanh."})

    analysis = sess.get("analysis_cache")
    if analysis is None and df is not None:
        analysis = ce.compute_deep_analysis(df, sess.get("business", {}))
        sess["analysis_cache"] = analysis

    numeric_cols = df.select_dtypes(include=['number']).columns.tolist() if df is not None else []
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist() if df is not None else []
    revenue_col = next((c for c in numeric_cols if any(k in ce.normalize_col_name(c) for k in ["doanh thu", "doanh so", "revenue", "sales", "thanh tien"])), numeric_cols[0] if numeric_cols else None)
    cost_col = next((c for c in numeric_cols if any(k in ce.normalize_col_name(c) for k in ["chi phi", "gia von", "cost", "cogs"])), None)
    profit_col = next((c for c in numeric_cols if any(k in ce.normalize_col_name(c) for k in ["loi nhuan", "lai", "profit"])), None)

    ans = ce.handle_ai_question(user_q, df, sess.get("business", {}), revenue_col, cost_col, profit_col, cat_cols, numeric_cols)
    return session_json_response(sess_id, {"answer": ans})

@app.route('/api/ai-refine-analysis', methods=['POST'])
def api_ai_refine_analysis():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    user_feedback = req.get("feedback", "").strip()
    df = sess.get("cleaned_df", sess.get("raw_df"))

    analysis = sess.get("analysis_cache")
    if analysis is None and df is not None:
        analysis = ce.compute_deep_analysis(df, sess.get("business", {}))
        sess["analysis_cache"] = analysis

    ai_suggestion = ce.generate_analysis_refinement(user_feedback, df, analysis)
    prev_notes = sess.get("report_custom_notes", "")
    if user_feedback and user_feedback not in prev_notes:
        sess["report_custom_notes"] = (prev_notes + f"\n- Hiệu chỉnh người dùng: {user_feedback} (AI: {ai_suggestion})").strip()

    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "ai_suggestion": ai_suggestion,
        "updated_analysis": analysis
    })

@app.route('/api/ai-refine-report', methods=['POST'])
def api_ai_refine_report():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    req = request.get_json(silent=True) or {}
    report_feedback = req.get("feedback", "").strip()
    sess["report_custom_notes"] = report_feedback
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {
        "success": True,
        "message": "Đã lưu ghi chú hiệu chỉnh vào báo cáo thành công."
    })

@app.route('/api/executive-report', methods=['GET'])
def api_executive_report():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    df = sess.get("cleaned_df", sess.get("raw_df"))
    if df is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu"}, 400)

    analysis = sess.get("analysis_cache")
    if analysis is None:
        analysis = ce.compute_deep_analysis(df, sess.get("business", {}))
        sess["analysis_cache"] = analysis

    charts = ce.generate_executive_charts(analysis, df)
    filename = sess.get("filename") or "du_lieu_kinh_doanh_mau.csv"
    biz = sess.get("business") or {}
    custom_notes = sess.get("report_custom_notes", "")

    report_model = ce.build_dynamic_report_model(df, filename, biz, analysis, custom_notes)
    report_model["meta"]["session_id"] = sess_id
    # Only keep base64 strings and non-stream objects for JSON response
    report_model["charts"] = {k: v for k, v in charts.items() if not k.endswith("_stream")}

    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, report_model)

@app.route('/api/export-docx', methods=['GET'])
def api_export_docx():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    docx_bytes = ce.export_docx_bytes(sess)
    if docx_bytes is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu để xuất"}, 400)

    resp = make_response(docx_bytes)
    resp.headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    resp.headers["Content-Disposition"] = "attachment; filename=Bao_Cao_Dieu_Hanh_KTCM_Studio.docx"
    resp.headers["X-Session-ID"] = sess_id
    return resp

@app.route('/api/export-html', methods=['GET'])
def api_export_html():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    html_str = ce.export_html_str(sess)
    resp = make_response(html_str)
    resp.headers["Content-Type"] = "text/html; charset=utf-8"
    resp.headers["Content-Disposition"] = "attachment; filename=Bao_Cao_Dieu_Hanh_KTCM_Studio.html"
    resp.headers["X-Session-ID"] = sess_id
    return resp

@app.route('/api/html-content', methods=['GET'])
def api_html_content():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    html_str = ce.export_html_str(sess)
    resp = make_response(html_str)
    resp.headers["Content-Type"] = "text/html; charset=utf-8"
    resp.headers["X-Session-ID"] = sess_id
    return resp

@app.route('/api/export-excel', methods=['GET'])
def api_export_excel():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    excel_bytes = ce.export_excel_bytes(sess)
    if excel_bytes is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu để xuất"}, 400)

    resp = make_response(excel_bytes)
    resp.headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    resp.headers["Content-Disposition"] = "attachment; filename=KTCM_Du_Lieu_Da_Lam_Sach.xlsx"
    resp.headers["X-Session-ID"] = sess_id
    return resp

@app.route('/api/export-csv', methods=['GET'])
def api_export_csv():
    sess_id, sess = get_current_session()
    ensure_session_data(sess)
    csv_bytes = ce.export_csv_bytes(sess)
    if csv_bytes is None:
        return session_json_response(sess_id, {"error": "Chưa có dữ liệu để xuất"}, 400)

    resp = make_response(csv_bytes)
    resp.headers["Content-Type"] = "text/csv; charset=utf-8-sig"
    resp.headers["Content-Disposition"] = "attachment; filename=KTCM_Du_Lieu_Da_Lam_Sach.csv"
    resp.headers["X-Session-ID"] = sess_id
    return resp

@app.route('/api/contact-submit', methods=['POST'])
def api_contact_submit():
    sess_id, sess = get_current_session()
    req = request.get_json(silent=True) or {}
    sess["feedbacks"].append(req)
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {"success": True, "message": "Yêu cầu đã được gửi thành công!"})

@app.route('/api/submit-feedback', methods=['POST'])
def api_submit_feedback():
    sess_id, sess = get_current_session()
    req = request.get_json(silent=True) or {}
    sess["feedbacks"].append(req)
    session_manager.save(sess_id, sess)
    return session_json_response(sess_id, {"success": True, "message": "Cảm ơn bạn đã đóng góp ý kiến!"})

# ==============================================================================
# STATIC FILE SERVING FOR LOCAL DEVELOPMENT
# ==============================================================================

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_static(path):
    if path == "" or path == "index.html":
        return send_from_directory(STATIC_DIR, "index.html")
    if os.path.exists(os.path.join(STATIC_DIR, path)):
        return send_from_directory(STATIC_DIR, path)
    return send_from_directory(STATIC_DIR, "index.html")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"KTCM AI Analytics Studio Flask Server running on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
