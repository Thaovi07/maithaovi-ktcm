"""
KTCM AI Analytics Studio - Multi-tenant Session Management
Compatible with both Local Development and Vercel Serverless Function instances.
"""
import os
import time
import uuid
import zlib
import pickle
import urllib.request
import json

class SessionStore:
    def __init__(self, ttl_seconds=7200):
        self.ttl = ttl_seconds
        # In-memory dictionary cache with TTL
        self._memory_store = {}
        # Upstash Redis REST credentials (if configured in Vercel environment variables)
        self.upstash_url = os.environ.get("UPSTASH_REDIS_REST_URL")
        self.upstash_token = os.environ.get("UPSTASH_REDIS_REST_TOKEN")
        
    def _create_empty_session(self, session_id):
        return {
            "session_id": session_id,
            "filename": None,
            "business": {
                "industry": "",
                "background": "",
                "questions": ""
            },
            "discovery": None,
            "raw_df": None,
            "cleaned_df": None,
            "audited_df": None,
            "clean_log": [],
            "clean_diff_cells": [],
            "clean_stats": {},
            "audit_changes": [],
            "is_audited": False,
            "analysis_cache": None,
            "report_custom_notes": "",
            "feedbacks": [],
            "created_at": time.time(),
            "last_accessed": time.time()
        }

    def _cleanup_expired(self):
        now = time.time()
        expired_keys = [k for k, v in self._memory_store.items() if now - v.get("last_accessed", 0) > self.ttl]
        for k in expired_keys:
            try:
                del self._memory_store[k]
            except KeyError:
                pass

    def get(self, session_id):
        if not session_id:
            return None
            
        # 1. Try local memory cache
        now = time.time()
        if session_id in self._memory_store:
            sess = self._memory_store[session_id]
            if now - sess.get("last_accessed", 0) <= self.ttl:
                sess["last_accessed"] = now
                return sess
            else:
                del self._memory_store[session_id]

        # 2. Try Upstash Redis REST if configured
        if self.upstash_url and self.upstash_token:
            try:
                req_url = f"{self.upstash_url}/get/session_{session_id}"
                req = urllib.request.Request(req_url, headers={"Authorization": f"Bearer {self.upstash_token}"})
                with urllib.request.urlopen(req, timeout=3) as resp:
                    res_data = json.loads(resp.read().decode('utf-8'))
                    raw_val = res_data.get("result")
                    if raw_val:
                        # Decompress and unpickle
                        compressed = bytes.fromhex(raw_val)
                        sess = pickle.loads(zlib.decompress(compressed))
                        sess["last_accessed"] = now
                        self._memory_store[session_id] = sess
                        return sess
            except Exception as e:
                print(f"[SessionStore] Upstash Redis GET error: {e}")

        return None

    def save(self, session_id, session_data):
        if not session_id or not session_data:
            return
            
        session_data["last_accessed"] = time.time()
        self._memory_store[session_id] = session_data
        self._cleanup_expired()

        # Sync to Upstash Redis REST if configured
        if self.upstash_url and self.upstash_token:
            try:
                compressed = zlib.compress(pickle.dumps(session_data, protocol=pickle.HIGHEST_PROTOCOL))
                hex_data = compressed.hex()
                req_url = f"{self.upstash_url}/set/session_{session_id}/{hex_data}/EX/{self.ttl}"
                req = urllib.request.Request(req_url, headers={"Authorization": f"Bearer {self.upstash_token}"})
                with urllib.request.urlopen(req, timeout=3) as resp:
                    pass
            except Exception as e:
                print(f"[SessionStore] Upstash Redis SET error: {e}")

    def get_or_create(self, session_id=None):
        if session_id:
            existing = self.get(session_id)
            if existing:
                return session_id, existing
                
        new_id = str(uuid.uuid4())
        new_sess = self._create_empty_session(new_id)
        self.save(new_id, new_sess)
        return new_id, new_sess

# Singleton instance
session_manager = SessionStore()
